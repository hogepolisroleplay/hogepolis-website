import React from 'react'

export default function HogepolisLanding() {
  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center">
      <h1 className="text-5xl font-bold mb-6">Welkom bij Hogepolis Roleplay</h1>
      <p className="text-lg mb-4">Een FiveM Roleplay server met realistische gameplay en een actieve community.</p>

      <nav className="flex gap-4 mb-6">
        <a href="#sollicitatie" className="bg-blue-600 px-4 py-2 rounded">Solliciteren</a>
        <a href="#doneren" className="bg-green-600 px-4 py-2 rounded">Doneren</a>
        <a href="#regels" className="bg-red-600 px-4 py-2 rounded">Regels</a>
        <a href="#contact" className="bg-gray-700 px-4 py-2 rounded">Contact</a>
      </nav>

      <section id="sollicitatie" className="max-w-2xl text-center mb-8">
        <h2 className="text-3xl font-bold mb-2">Solliciteren</h2>
        <p>Word onderdeel van de Hogepolis staff! Vul het sollicitatieformulier in via onze Discord.</p>
      </section>

      <section id="doneren" className="max-w-2xl text-center mb-8">
        <h2 className="text-3xl font-bold mb-2">Doneren</h2>
        <p>Steun de server en krijg exclusieve voordelen. Doneren kan via onze website of Discord.</p>
      </section>

      <section id="regels" className="max-w-2xl text-center mb-8">
        <h2 className="text-3xl font-bold mb-2">Regels</h2>
        <p>Lees altijd de regels voor je speelt. Respect, eerlijkheid en roleplay staan voorop.</p>
      </section>

      <section id="contact" className="max-w-2xl text-center mb-8">
        <h2 className="text-3xl font-bold mb-2">Contact</h2>
        <p>Vragen? Join onze Discord voor support en informatie.</p>
      </section>

      <footer className="mt-8 text-sm text-gray-400">© 2025 Hogepolis Roleplay</footer>
    </div>
  )
}